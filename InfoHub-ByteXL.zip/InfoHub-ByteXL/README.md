# InfoHub — ByteXL Challenge

A single‑page React app backed by an Express API that delivers:
- Weather by city (Open‑Meteo)
- Currency conversion (INR → USD/EUR via frankfurter.app)
- Motivational quotes (mock or live via Quotable)

## Run locally
### 1) Backend
```bash
cd server
npm install
npm start
# -> http://localhost:3001
```

### 2) Frontend
```bash
cd ../client
npm install
npm run dev
# -> http://localhost:5173
```

Optional: create `client/.env` with `VITE_API_BASE=http://localhost:3001`.

## Deploy
- Backend: Render (Web Service) — Start: `node server.js`
- Frontend: Vercel — Env: `VITE_API_BASE=<your backend URL>`

## API
- `GET /api/weather?city=Hyderabad`
- `GET /api/currency?amount=1000`
- `GET /api/quote[?live=true]`

All responses follow: `{ ok, data|error }`.
