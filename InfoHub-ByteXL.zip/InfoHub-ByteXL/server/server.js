// server/server.js
import express from 'express';
import cors from 'cors';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const ok = (res, data) => res.status(200).json({ ok: true, data });
const fail = (res, code = 500, msg = 'Something went wrong') => res.status(code).json({ ok: false, error: msg });

const QUOTES = [
  'Start where you are. Use what you have. Do what you can.',
  'Discipline beats motivation when motivation fades.',
  'Small steps every day compound into big results.',
  'You don’t have to be great to start, but you have to start to be great.',
  'Focus on progress, not perfection.',
  'Consistency is a superpower.',
  'If it costs you your peace, it’s too expensive.',
  'Dream big. Start small. Act now.',
  'Make it simple. Make it work. Make it right.',
  'Done is better than perfect.'
];

app.get('/api/quote', async (req, res) => {
  try {
    const useLive = String(req.query.live || '').toLowerCase() === 'true';
    if (useLive) {
      const r = await axios.get('https://api.quotable.io/random');
      return ok(res, { text: r.data.content, author: r.data.author || 'Unknown' });
    }
    const text = QUOTES[Math.floor(Math.random() * QUOTES.length)];
    return ok(res, { text, author: '—' });
  } catch {
    return fail(res, 500, 'Could not fetch a quote.');
  }
});

app.get('/api/weather', async (req, res) => {
  try {
    const city = (req.query.city || '').toString().trim();
    if (!city) return fail(res, 400, 'City is required.');

    const geo = await axios.get('https://geocoding-api.open-meteo.com/v1/search', {
      params: { name: city, count: 1, language: 'en', format: 'json' }
    });
    const place = geo.data && geo.data.results && geo.data.results[0];
    if (!place) return fail(res, 404, 'City not found.');

    const { latitude, longitude, name, country } = place;

    const meteo = await axios.get('https://api.open-meteo.com/v1/forecast', {
      params: { latitude, longitude, current_weather: true }
    });

    const cw = meteo.data.current_weather;
    if (!cw) return fail(res, 502, 'Weather unavailable right now.');

    ok(res, {
      location: `${name}, ${country}`,
      temperatureC: cw.temperature,
      windKph: cw.windspeed,
      description: `Code ${cw.weathercode}`,
      timeISO: cw.time
    });
  } catch {
    return fail(res, 500, 'Could not fetch weather data.');
  }
});

app.get('/api/currency', async (req, res) => {
  try {
    const amount = Number(req.query.amount || '');
    if (!Number.isFinite(amount) || amount < 0) return fail(res, 400, 'Amount must be a non‑negative number.');

    const r = await axios.get('https://api.frankfurter.app/latest', {
      params: { from: 'INR', to: 'USD,EUR' }
    });

    const rates = r.data && r.data.rates ? r.data.rates : null;
    if (!rates) return fail(res, 502, 'Rates unavailable.');

    const usd = +(amount * rates.USD).toFixed(2);
    const eur = +(amount * rates.EUR).toFixed(2);

    ok(res, { base: 'INR', amount, usd, eur, asOf: r.data.date });
  } catch {
    return fail(res, 500, 'Could not fetch currency rates.');
  }
});

app.get('/api/health', (_, res) => ok(res, { service: 'infohub-api', status: 'up' }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`API ready on http://localhost:${PORT}`));
