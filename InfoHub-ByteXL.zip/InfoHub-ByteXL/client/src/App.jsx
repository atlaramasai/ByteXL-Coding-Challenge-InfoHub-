import { useState } from 'react'
import WeatherModule from './components/WeatherModule.jsx'
import CurrencyConverter from './components/CurrencyConverter.jsx'
import QuoteGenerator from './components/QuoteGenerator.jsx'

const TABS = ['Weather', 'Converter', 'Quotes']

export default function App(){
  const [tab, setTab] = useState('Weather')

  return (
    <div className="container">
      <header className="header">
        <h1 className="brand">InfoHub</h1>
        <nav className="tabs">
          {TABS.map(t => (
            <button key={t} className={`tab ${tab===t ? 'active':''}`} onClick={() => setTab(t)}>{t}</button>
          ))}
        </nav>
      </header>

      <section className="grid">
        {tab === 'Weather' && <WeatherModule />}
        {tab === 'Converter' && <CurrencyConverter />}
        {tab === 'Quotes' && <QuoteGenerator />}
      </section>

      <p className="footer">No page reloads. Proper loading & error states. API: /api/weather • /api/currency • /api/quote</p>
    </div>
  )
}
