import { useState } from 'react'
import axios from 'axios'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:3001'

export default function CurrencyConverter(){
  const [amount, setAmount] = useState('100')
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const convert = async () => {
    try {
      setLoading(true); setError(''); setData(null)
      const r = await axios.get(`${API}/api/currency`, { params: { amount } })
      if (!r.data.ok) throw new Error(r.data.error || 'Unknown error')
      setData(r.data.data)
    } catch (e) {
      setError(e.message || 'Failed to convert')
    } finally { setLoading(false) }
  }

  return (
    <div className="card">
      <h2>INR → USD/EUR</h2>
      <div style={{display:'grid', gap:8, gridTemplateColumns:'1fr auto'}}>
        <input className="input" inputMode="decimal" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="Amount in INR" />
        <button className="button" onClick={convert}>Convert</button>
      </div>
      {loading && <div className="loader">Converting…</div>}
      {error && <div className="err">{error}</div>}
      {data && (
        <div style={{marginTop:8}}>
          <div className="kv"><span>{data.amount} INR in USD</span><strong className="ok">${data.usd}</strong></div>
          <div className="kv"><span>{data.amount} INR in EUR</span><strong className="ok">€{data.eur}</strong></div>
          <div className="kv"><span>Rates date</span><span className="muted">{data.asOf}</span></div>
        </div>
      )}
      <p className="muted">Live rates via frankfurter.app</p>
    </div>
  )
}
