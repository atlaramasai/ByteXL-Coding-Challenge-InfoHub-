import { useEffect, useState } from 'react'
import axios from 'axios'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:3001'

export default function WeatherModule(){
  const [city, setCity] = useState('Hyderabad')
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const fetchWeather = async () => {
    try {
      setLoading(true); setError(''); setData(null)
      const r = await axios.get(`${API}/api/weather`, { params: { city } })
      if (!r.data.ok) throw new Error(r.data.error || 'Unknown error')
      setData(r.data.data)
    } catch (e) {
      setError(e.message || 'Failed to load weather')
    } finally { setLoading(false) }
  }

  useEffect(() => { fetchWeather() }, [])

  return (
    <div className="card">
      <h2>Weather</h2>
      <div style={{display:'grid', gap:8, gridTemplateColumns:'1fr auto'}}>
        <input className="input" value={city} onChange={e=>setCity(e.target.value)} placeholder="City name" />
        <button className="button" onClick={fetchWeather}>Check</button>
      </div>
      {loading && <div className="loader">Loading weather…</div>}
      {error && <div className="err">{error}</div>}
      {data && (
        <div style={{marginTop:8}}>
          <div className="kv"><span>Location</span><strong>{data.location}</strong></div>
          <div className="kv"><span>Temperature</span><strong>{data.temperatureC} °C</strong></div>
          <div className="kv"><span>Wind</span><strong>{data.windKph} km/h</strong></div>
          <div className="kv"><span>As of</span><span className="muted">{new Date(data.timeISO).toLocaleString()}</span></div>
        </div>
      )}
      <p className="muted">Powered by Open‑Meteo. No key needed.</p>
    </div>
  )
}
