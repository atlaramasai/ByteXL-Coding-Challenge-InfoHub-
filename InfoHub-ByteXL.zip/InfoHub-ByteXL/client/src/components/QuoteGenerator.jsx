import { useEffect, useState } from 'react'
import axios from 'axios'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:3001'

export default function QuoteGenerator(){
  const [quote, setQuote] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [live, setLive] = useState(false)

  const fetchQuote = async () => {
    try {
      setLoading(true); setError(''); setQuote(null)
      const r = await axios.get(`${API}/api/quote`, { params: { live } })
      if (!r.data.ok) throw new Error(r.data.error || 'Unknown error')
      setQuote(r.data.data)
    } catch (e) {
      setError(e.message || 'Failed to load quote')
    } finally { setLoading(false) }
  }

  useEffect(() => { fetchQuote() }, [])

  return (
    <div className="card">
      <h2>Motivational Quote</h2>
      <label style={{display:'flex', gap:8, alignItems:'center', marginBottom:8}}>
        <input type="checkbox" checked={live} onChange={e=>setLive(e.target.checked)} />
        <span className="muted">Use live API</span>
      </label>
      <button className="button" onClick={fetchQuote}>New Quote</button>
      {loading && <div className="loader">Thinking…</div>}
      {error && <div className="err">{error}</div>}
      {quote && (
        <blockquote style={{marginTop:12, lineHeight:1.5}}>
          <div>“{quote.text}”</div>
          <div className="muted" style={{marginTop:6}}>{quote.author}</div>
        </blockquote>
      )}
    </div>
  )
}
